"""
Medium 1
Write a Python function called remove_duplicate_words that takes a string as input and returns a new string with all duplicate WORDS removed. For example, if the input string is "This land is your land, this land is my land.", the output should be "This land is your, this my.". You must be able to deal with the punctuation and ignore case.
"""


def remove_duplicate_words(input_str):
    # Your code here
    pass  # the word "pass" is used to let python know we are going to use this level of indentation (due to the colon on the previous line) but we have not yet implemented the code for this function


# end medium 1
# ---------------------------------------
"""
Medium 2

Write a Python function called validate_email that takes an email address as input and returns True if the email address is valid and False otherwise. A valid email address should have the following characteristics:

- It should have exactly one '@' symbol.
- The local part (before the '@' symbol) should contain only alphanumeric characters, dots ('.'), hyphens ('-'), and underscores ('_').
- The domain part (after the '@' symbol) should contain only alphanumeric characters and dots ('.'), and it should have at least one dot.
- The domain part should have at least two characters after the last dot.
"""
import re


def validate_email(email):
    # Your code here
    pass


# end medium 2
# ---------------------------------------
"""
Medium 3

Write a Python function called word_count that takes a string as input and returns a dictionary containing the count of each word in the string. Words are separated by whitespace and should be considered case-insensitive. Punctuation should be ignored. For example, if the input string is "Hello world! Hello again world", the output dictionary should be {'hello': 2, 'world': 2, 'again': 1}.
"""
import re


def word_count(input_str):
    # Your code here
    pass


# end medium 3
# ---------------------------------------
"""
Medium 4

Write a Python function called validate_password that takes a password as input and returns True if the password is valid and False otherwise. A valid password should have the following characteristics:

- It should be at least 8 characters long and at most 20 characters long.
- It should contain at least one uppercase letter, one lowercase letter, one digit, and one special character (any character other than letters and digits).
"""
import re


def validate_password(password):
    pass


# end medium 4
# ---------------------------------------
""" 
Medium 5

Write a Python function called extract_links that takes a string containing HTML code as input and returns a list of unique URLs found within the HTML code. URLs should start with "http://" or "https://". You can assume that URLs are enclosed in anchor tags <a> and have the format <a href="URL">. You may ignore any additional attributes in the anchor tags.
"""
import re


def extract_links(html_code):
    # Your code here
    pass


# end medium 5
# ---------------------------------------
"""
Medium 6.0

Write a python member function (of class Point) called distance_to that takes an additional point (x2, y2) as input and returns the distance between itself and that point. The distance between two points (x1, y1) and (x2, y2) is calculated as follows: d=sqrt((x2 – x1)^2 + (y2 – y1)^2).
"""
"""
Medium 6.5
Fix the 'to string' function (of class Point) called __reper__. This function is supposed to return a string representation of the point in the form (x, y) where x and y are the coordinates of the point. However right now it just returns the string-literal: "(x, y)"

Note: Every python class has a special function called __repr__ that is automatically called when you print an object of that class.

- for other "special" python methods visit the following to learn more: https://www.pythonlikeyoumeanit.com/Module4_OOP/Special_Methods.html
"""
import math


class Point:

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def distance_to(self, other) -> int:
        return 0

    def __reper__(self) -> str:
        return f"(6, 9)"  # fix this (6.5)


# end medium 6
# ---------------------------------------
