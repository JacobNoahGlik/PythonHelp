"""
Hard 1

Write a Python function called anagram_groups that takes a list of strings as input and returns a list of lists, where each inner list contains words that are anagrams of each other. Anagrams are words that have the same characters but in a different order. The output list should be sorted lexicographically and the inner lists should be sorted in ascending order of their lengths.

Example:
  words = ["listen", "silent", "hello", "world", "act", "cat", "ball", "fall", "tap", "pat"]
  print(anagram_groups(words))  
  # Output should be [['act', 'cat'], ['ball', 'fall'], ['listen', 'silent'], ['pat', 'tap'], ['hello', 'world']]
"""
def anagram_groups(words):
    map = {}
    # Your code here
    pass


# end hard 1
# ---------------------------------------

"""
Hard 2

Write a Python function called find_longest_substring that takes a string as input and returns the longest substring that contains at most two distinct characters. If there are multiple substrings with the same length, return the one that appears first in the string.

example:
inputstring = "abcbbbbcccbdddadacb"
print(find_longest_substring(inputstring))
# output should be 'cbbbbcccb'
 - it only contains c's and b's and they are consecutive
"""

def find_longest_substring(s):
    if not s:
        return ""
    pass


# end hard 2
# ---------------------------------------

"""
Hard 3

Write a Python function called merge_intervals that takes a list of intervals as input and returns a list of intervals after merging overlapping intervals. An interval is represented as a list [start, end], where start and end are integers. Overlapping intervals should be merged, for example, [[1, 3], [2, 6], [8, 10], [15, 18]] should be merged to [[1, 6], [8, 10], [15, 18]].
"""
def merge_intervals(intervals):
    if not intervals:
        return []

    # Sort intervals based on the start time
    # Check for overlap
    # Merge the intervals
    pass


# end hard 3
# ---------------------------------------
