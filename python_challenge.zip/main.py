import test
import sys

if len(sys.argv) not in [1, 2]:
    print('USAGE: py main.py -all')
    print('USAGE: py main.py <test_name>')
    print('\ttest_name options:')
    print('\t\t-easy')
    print('\t\t-medium')
    print('\t\t-hard')
    print('\t\t-io')
    print('USAGE: py main.py')
    exit(1)

tests = [test.easy, test.medium, test.hard, test.io]
names = ['Easy', 'Medium', 'Hard', 'IO_Challenge']

if len(sys.argv) == 1:
    for (name, test) in zip(names, tests):
        try:
            test()
        except Exception as e:
            print('\n\n\n\n____________________')
            print(f'EXCEPTION CAUGHT IN {name}.PY FILE')
            print('EXCEPTION IS AS FOLLOWS:\n')
            raise e

test_names = ['-easy', '-medium', '-hard', '-io']
if sys.argv[1].lower() not in test_names:
    print('ERROR: Invalid test name')
    print(f'\tExpected: {test_names}')
    print(f"\tGot:      '{sys.argv[1].lower()}'")
    exit(1)

tests[test_names.index(sys.argv[1].lower())]()
