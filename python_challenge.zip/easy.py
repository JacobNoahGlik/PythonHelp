"""
Easy 1
Write a Python function called reverse_vowels that takes a string as input and returns a new string with the vowels reversed. For example, if the input string is "hello world", the output should be "hollo werld".
"""
def reverse_vowels(input_str):
    vowels = 'aeiouAEIOU'
    # Your code here


# end easy 1
# ---------------------------------------


"""
Easy 2
Write a Python function called remove_duplicates that takes a string as input and returns a new string with all duplicate characters removed. For example, if the input string is "hello world", the output should be "helo wrd".
"""
def remove_duplicates(input_str):
    # Your code here
    pass # the word "pass" is used to let python know we are going to use this level of indentation (due to the colon on the previous line) but we have not yet implemented the code for this function


# end easy 2
# ---------------------------------------

"""
Easy 3
Write a Python function called reverse_words that takes a string as input and returns a new string with the order of words reversed. For example, if the input string is "My name is Tina", the output should be "Tina is name My".
"""
def reverse_words(input_str):
    # Your code here
    pass # the word "pass" is used to let python know we are going to use this level of indentation (due to the colon on the previous line) but we have not yet implemented the code for this function


# end easy 3
# ---------------------------------------


"""
Easy 4
Write a Python function called even_length_words that takes a list of words as input and returns a new list containing only the words with an even number of characters. For example, if the input list is ["hello", "world", "python", "programming"], the output should be ["python"].
"""
def even_length_words(words):
    # Your code here
    pass


# end easy 4
# ---------------------------------------
