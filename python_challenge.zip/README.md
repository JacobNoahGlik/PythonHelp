# Python Challenge
###### String / list comprehension focused

<br>

To test all: run `py main.py -all` for windows or `python3 main.py -all` for linux 

To test easy/medium/hard/io: run `py main.py -<easy/medium/hard/io>` for windows or `python3 main.py -<easy/medium/hard/io>` for linux 



