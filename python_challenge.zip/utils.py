import medium

class Colors:
    @staticmethod
    def clear():
        return "\033[0m"

    @staticmethod
    def green():
        return "\033[92m"

    @staticmethod
    def red():
        return "\033[1;31m"

    @staticmethod
    def yellow():
        return "\033[93m"

    @staticmethod
    def bold():
        return "\033[1m"


def print_error(message, _prefix='[ERROR] ', _postfix='', _end='\n', _then_exit=True):
    print(f"{Colors.red()}{_prefix}{message}{Colors.clear()}{_postfix}", end=_end)
    if _then_exit: 
        exit()

def print_warning(message, _prefix='X [WARNING] ', _postfix='', _end='\n'):
    print(f"{Colors.yellow()}{_prefix}{message}{Colors.clear()}{_postfix}", end=_end)

def print_success(message, _postfix='', _end='\n'):
    print(f"{Colors.green()}{message}{Colors.clear()}{_postfix}", end=_end)

def print_bold(message, _postfix='', _end='\n'):
    print(f"{Colors.bold()}{message}{Colors.clear()}{_postfix}", end=_end)

def checkmark():
    return u'\u2713'

def test_function(fname, func, input, expected, range=False, type='', _is_point=False, _no_arg=False, _eq=False, _input_split=False):
    if not _eq:
        if not _input_split:
            output = func() if _no_arg else func(input)
        else:
            output = func(*input)
        if not range and output == expected or range and output > expected[0] and output < expected[1]:
            print_success(f"{checkmark()}\t{fname} passed ", _postfix=type)
            return 1
        if _is_point:
            input = f'( ({_is_point.x}, {_is_point.y}).distance_to({input.x}, {input.y}) )'
        type_str = make_warn(type)
        print_warning(f'{fname} failed{type_str}\n\t{input    = }\n\t{output   = }\n\t{expected = }')
    else:
        func(input, 'out.tmp') if not _input_split else func(*input, 'out.tmp')
        if _eq[0]('out.tmp', expected):
            print_success(f"{checkmark()}\t{fname} passed ", _postfix=type)
            filewhipe('out.tmp')
            return 1
        type_str = make_warn(type)
        output = _eq[1]('out.tmp')
        filewhipe('out.tmp')
        print_warning(f'{fname} failed{type_str}\n\t{input    = }\n\t{output   = }\n\t{expected = }')
    return 0

def make_warn(type):
    if type == '':
        return ''
    return f'{Colors.clear()} {type}{Colors.yellow()}'

def outcome(name, passed, total, force=True):
    if passed == total:
        print_success(f"{name} tests passed ({passed}/{total}) {round(passed/total*100, 1)}%   ", _postfix=checkmark())
    else:
        print_error(f"{name} tests passed ({passed}/{total}) {round(passed/total*100, 1)}%   X", _then_exit=force)
    print('')

import os
def filewhipe(filename):
    if os.path.exists(filename):
        os.remove(filename)