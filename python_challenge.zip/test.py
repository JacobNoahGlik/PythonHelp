from utils import test_function, outcome

def easy(force=True):
    import easy
    passed = 0
    total = 4
    print("Testing Easy -------------------")
    passed += test_function('Easy 1', easy.reverse_vowels, "hello world", 'hollo werld')
    print('\t-------------------------------')
    passed += test_function('Easy 2', easy.remove_duplicates, "hello world", 'helo wrd')
    print('\t-------------------------------')
    passed += test_function('Easy 3', easy.reverse_words, "hello world", 'world hello')
    print('\t-------------------------------')
    passed += test_function(
        'Easy 4', 
        easy.even_length_words, 
        ["hello", "world", "python", "programming"], 
        ['python']
    )
    outcome('Easy', passed, total, force=force)


def medium(force=True):
    import medium
    passed = 0
    total = 33
    print("Testing Medium -------------------")
    for i, (input, expected, type) in enumerate([
        ("an apple is a fruit not all fruits are apples", "an apple is a fruit not all fruits are apples", '(no duplicate words)'),
        ("This land is your land, this land is my land.", "This land is your, my.", '(basic duplicate words)'),
        ("I love you, I love you, I love you, I love you.", "I love you,,,.", '(duplicate words with punctuation)')
    ]):
        passed += test_function(f'Medium 1.{i}', medium.remove_duplicate_words, input, expected, type=type)
    print('\t-------------------------------')
    for i, (email, expectation, type) in enumerate([
        ('jacob@gmail.com', True, '(basic valid email)'),
        ('mark99I$cool@iname.com', False, '(illigal char: dollar sign)'),
        ('mark99_Is-Cool@iname.com', True, '(valid email)'),
        ('mathew.james@email.net', True, '(valid email with periods)'),
        ('@email.net', False, '(invalid email: missing name)'),
        ('.com', False, '(invalid email: missing name and domain)'),
        ('fail@test.z', False, '(invalid email: domain too short)'),
        ('pass.multi.dot.test@my.email.co.uk', True, '(valid email: long domain)')
    ]):
        passed += test_function(f'Medium 2.{i}', medium.validate_email, email, expectation, type=type)
    print('\t-------------------------------')
    for i, (words, count, type) in enumerate([
        ('', {}, '(empty string)'),
        ('apple', {'apple': 1}, '(single word)'),
        ('apple banana', {'apple': 1, 'banana': 1}, '(unique occurrences)'),
        ("The club isn't the best place to find a lover So the bar is where I go", {
            'the': 3, 'club': 1, "isn't": 1, 'best': 1, 'place': 1, 'to': 1, 'find': 1, 
            'a': 1, 'lover': 1, 'so': 1, 'bar': 1, 'is': 1, 'where': 1, 'i': 1, 'go': 1,
        }, '(song lyrics)'),
        ('How much wood would a woodchuck chuck if a woodchuck could chuck wood? He' 
         ' would chuck, he would, as much as he could, and chuck as much wood as a wood'
         'chuck would chuck wood', {
            'how': 1, 'much': 3, 'wood': 4, 'would': 4, 'chuck': 5, 'if': 1, 'could': 2, 
            'as': 4, 'woodchuck': 3, 'a': 3, 'he': 3, 'and': 1
         }, '(tongue twister)')
    ]):
        passed += test_function(f'Medium 3.{i}', medium.word_count, words, count, type=type)
    print('\t-------------------------------')
    first = True
    for i, (inp, type) in enumerate([
        ("Password@123", '(basic legal password)'),
        ("$H0Rt", '(too short)'),
        ("PasswordWAAAAAAAAAAAYTooLong@1", '(too long)'), 
        ("UPPERCA$E19", '(missing lowercase)'),
        ("lowercase7-", '(mussing uppercase)'),
        ("NoNumbers!", '(missing numbers)')
    ]):
        passed += test_function(f'Medium 4.{i}', medium.validate_password, inp, first, type=type)
        first = False
    print('\t-------------------------------')
    for i, (html, links, type) in enumerate([
        ('<h1>Ignore this text</h1>', [], '(no links)'),
        ('<h1>Ignore this text</h1> <a href="http://example.com">Example</a>', ['http://example.com'], '(single link)'),
        (' <h1>Ignore this text</h1> <a href="http://example.com">Example</a> <a href="'
         'https://google.com">Google</a> <p>More text</p>', ['http://example.com', 'https://google.com'], '(two links)'),
        (' <h1>Ignore this text</h1> <h2>The following is text not a link: https://missleading link.ru</h2> <a href="http://example.com">Example</a> <a href="'
         'https://google.com">Google</a> <p>More text</p>', ['http://example.com', 'https://google.com'], '(missleading link)')
    ]):
        passed += test_function(f'Medium 5.{i}', medium.extract_links, html, links, type=type)
    print('\t-------------------------------')
    origin = medium.Point(0,0)
    point1 = medium.Point(0,5)
    point2 = medium.Point(5,0)
    for i, (function, arg, expected, range, type) in enumerate([
        (origin, origin, 0, False, '(origin to origin)'),
        (origin, point1, 5, False, '(origin to (0, 5))'),
        (point2, origin, 5, False, '((5, 0) to origin)'),
        (point1, point2, [7.06, 7.09], True, '((0, 5) to (5, 0))')
    ]):
        passed += test_function(f'Medium 6.0.{i}', function.distance_to, arg, expected, range=range, type=type, _is_point=function)
    print('\t-------------------------------')
    for i, (point, expected, type) in enumerate([
        (origin, '(0, 0)', '(origin)'),
        (point1, '(0, 5)', '(point1)'),
        (point2, '(5, 0)', '(point2)')
    ]):
        passed += test_function(f'Medium 6.5.{i}', point.__reper__, None, expected, type=type, _no_arg=True)
    outcome('Medium', passed, total, force=force)

class Hard_Test:
    def __init__(self, tests):
        self.tests = tests
        self.size = sum([len(x) for x in self.tests])
    def get(self, index):
        return self.tests[index]

def hard(force=True):
    import hard
    __HT__ = Hard_Test([
        [ # 1
            ([], [], '(empty list)'),
            (['ate', 'hate', 'late', 'at'], [['ate'], ['hate'], ['late'], ['at']], '(zero annagrams)'),
            (['fate', 'feat', 'feta'], [sorted(['fate', 'feat', 'feta'])], '(single group)'),
            (['fate', 'feat', 'feta', 'grate', 'great', 'retag', 'targe', 'terga'], [sorted(['fate', 'feat', 'feta']), sorted(['grate', 'great', 'retag', 'targe', 'terga'])], '(multi group)')
        ],
        [ # 2
            ('aaaaaaa', 'aaaaaaa', '(single letter)'),
            ('aaaaaaabbbbbaaba', 'aaaaaaabbbbbaaba', '(two letters)'),
            ('aaaaaaacbbbbbaaba', 'bbbbbaaba', '(three letters)'),
            ('aaaabbbabeigjelaakddddkkkds', 'aaaabbbab', '(tie returns the first instance)')
        ],
        [ # 3
            ([[0, 1], [11, 14], [2, 3], [4, 7], [1, 5], [6, 19]], [[0, 19]], '(complete intersection)'),
            ([[0, 2], [5, 9], [15, 25]], [[0, 2], [5, 9], [15, 25]], '(no intersections)'),
            ([[1, 3], [2, 6], [8, 10], [15, 18]], [[1, 6], [8, 10], [15, 18]], '(example)')
        ]
    ])
    passed = 0
    print("Testing Hard -------------------")

    funcs = [hard.anagram_groups, hard.find_longest_substring, hard.merge_intervals]
    for number in range(0,3):
        for i, (input, expected, type) in enumerate(__HT__.get(number)):
            passed += test_function(f'Hard {number+1}.{i}', funcs[number], input, expected, type=type)
        print('\t-------------------------------')
    outcome('Hard', passed, __HT__.size, force=force)
"""

intervals = [[1, 3], [2, 6], [8, 10], [15, 18]]
print(merge_intervals(intervals))  # Output should be [[1, 6], [8, 10], [15, 18]]

input_str = "abcbbbbcccbdddadacb"
print(find_longest_substring(input_str))  # Output should be "bcbbbbcccb"

words = ["listen", "silent", "hello", "world", "act", "cat", "ball", "fall", "tap", "pat"]
print(anagram_groups(words))  
# Output should be [['act', 'cat'], ['ball', 'fall'], ['listen', 'silent'], ['pat', 'tap'], ['hello', 'world']]

"""


expected_str_yaml = """time,error_type,user,error_description,likely_cause
2024-02-1913:45:21,ERROR,sys-admin,Connectionrefused,timeout
2024-02-1913:47:15,ERROR,network-engineer,Databaseconnectionlost,networkissue
2024-02-1913:50:10,ERROR,dba,Filenotfound,deletedbymistake
2024-02-1913:51:27,ERROR,sys-admin,Servertimeout,heavyload
2024-02-1913:53:58,ERROR,developer,Databasequeryfailed,syntaxerror
2024-02-1913:55:09,ERROR,network-engineer,Memoryallocationerror,memoryleak
2024-02-1913:57:37,ERROR,sys-admin,Invalidinputreceived,usererror
2024-02-1913:58:49,ERROR,developer,Networkconnectionerror,firewallissue
2024-02-1914:01:17,ERROR,dba,Authenticationfailed,wrongcredentials
2024-02-1914:02:30,ERROR,sys-admin,Diskfailuredetected,hardwaremalfunction
2024-02-1914:03:45,ERROR,developer,Databasetablecorrupted,softwarebug
2024-02-1914:06:08,ERROR,network-engineer,Outofmemory,resourceexhaustion
2024-02-1914:08:34,ERROR,sys-admin,Configurationfilemissing,configurationerror
2024-02-1914:09:48,ERROR,developer,Servernotresponding,serveroverload
2024-02-1914:12:12,ERROR,user2947743,Diskspaceexhausted,hugefilecreation
2024-02-1914:13:27,ERROR,sys-admin,Filepermissionsdenied,accessrestriction
2024-02-1914:15:52,ERROR,network-engineer,Databaseconnectiontimeout,serverresponsedelay
2024-02-1914:17:07,ERROR,dba,Internalservererror,servermisconfiguration
2024-02-1914:19:33,ERROR,sys-admin,Serviceunavailable,servermaintenance
2024-02-1914:20:46,ERROR,developer,Serveroverloaddetected,hightraffic
2024-02-1914:23:10,ERROR,guest,Databasediskfull,storagecapacityexceeded
2024-02-1914:24:23,ERROR,sys-admin,Invalidconfigurationsettings,configurationerror
2024-02-1914:26:50,ERROR,developer,Datacorruptiondetected,dataintegrityissue
2024-02-1914:28:03,ERROR,network-engineer,Servercrashdetected,criticalfailure
2024-02-1914:30:28,ERROR,sys-admin,Softwarelicenseexpired,licenseexpiration
2024-02-1914:31:41,ERROR,developer,Hardwaremalfunction,faultyhardware
2024-02-1914:34:09,ERROR,network-engineer,Databasedeadlockdetected,databaseconflict
2024-02-1914:35:22,ERROR,user7658483,Serviceinterruption,servicemaintenance
2024-02-1914:37:47,ERROR,developer,Networkcongestion,highnetworktraffic
2024-02-1914:39:00,ERROR,network-engineer,Datalossdetected,datacorruption
2024-02-1914:41:26,ERROR,sys-admin,Invalidinputformat,inputvalidationfailure
2024-02-1914:42:38,ERROR,developer,APIkeyinvalid,authenticationfailure
2024-02-1914:45:04,ERROR,network-engineer,Systemoverload,resourceexhaustion
2024-02-1914:46:17,ERROR,user2947743,Memoryleakdetected,memorymanagementissue
2024-02-1914:48:42,ERROR,developer,Databaseconnectionpoolexhausted,resourcedepletion
2024-02-1914:49:54,ERROR,network-engineer,Permissiondenied,accessrestriction"""


def io(force=True):
    import io_challenge
    passed = 0
    __IO_TEST__ = Hard_Test([
        [ # IO 1
            ('io1_0.txt', '', '(empty file)'),
            ('io1_1.txt', 'hello world', '(basic file)'),
            ('io1_2.txt', "Yeah\nI know sometimes\nThings may not always make sense to you right now\nBut hey\nWhat Daddy always tell you?\nStraighten up, little soldier\nStiffen up that upper lip\nWhat you cryin' about?\nYou got me", '(multi-line file)')
        ],
        [ # IO 2
            ('io1_0.txt', 0, '(empty file)'),
            ('io1_1.txt', 2, '(basic file)'),
            ('io1_2.txt', 37, '(multi-line file)'),
            ('empty.txt', 0, '(invisible characters file)')
        ],
        [ # IO 3
            (0, '1', '(zero-th fib is 1)'),
            (4, '1 1 2 3 5', '(basic fib)'),
            (11, '1 1 2 3 5 8 13 21 34 55 89 144', '(long fib)')
        ],
        [ # IO 4
            ('io1_0.txt', 'io1_0.txt', '(blank file)'),
            ('io1_1.txt', 'io1_1.txt', '(single line file)'),
            ('io1_2.txt', 'io1_2_reverse.txt', '(multi-line file)')
        ],
        [ # IO 5
            (('io1_0.txt', 'SYS_ERROR'), [], '(empty file)'),
            (('err0.yaml', 'SYS_ERROR'), [], '(no errors)'),
            (('err0.yaml', 'WARNING'), ['Disk space low'], '(basic error log file)'),
            (('err0.yaml', 'ERROR'), ['Connection refused', 'Database connection lost'], '(basic multi-error log file)'),
            (('err2.yaml', 'ERROR'), 
             [
                'Connection refused', 'File not found', 'Server timeout', 'Memory allocation error', 
                'Invalid input received', 'Network connection error', 'Authentication failed', 
                'Disk failure detected', 'Out of memory', 'Configuration file missing', 
                'Server not responding', 'Disk space exhausted', 'File permissions denied', 
                'Internal server error', 'Service unavailable', 'Server overload detected', 
                'Invalid configuration settings', 'Data corruption detected', 'Server crash detected', 
                'Software license expired', 'Hardware malfunction', 'Service interruption', 
                'Network congestion', 'Data loss detected', 'Invalid input format', 'API key invalid', 
                'System overload', 'Memory leak detected', 'Permission denied', 'Network failure', 
                'Service unavailable'
             ], 
             '(large multi-error log file)')
        ],
        [ # filter_errors_to_csv(log_file, error_type, output_file)
            (('small_err.yaml', 'ERROR'), 'time,error_type,user,error_description,likely_cause\n2024-02-19 13:45:21,ERROR,sys-admin,Connection refused,timeout', '(small error log file)'),
            (('large_err.yaml', 'ERROR'), expected_str_yaml, '(large error log file)')
        ]
    ])
    print('Testing IO -------------------')
    for i, (input, expected, type) in enumerate(__IO_TEST__.get(0)):
        passed += test_function(f'IO 1.{i}', io_challenge.read_file, input, expected, type=type)
    print('\t-------------------------------')
    for i, (input, expected, type) in enumerate(__IO_TEST__.get(1)):
        passed += test_function(f'IO 2.{i}', io_challenge.count_words, input, expected, type=type)
    print('\t-------------------------------')
    for i, (input, expected, type) in enumerate(__IO_TEST__.get(2)):
        passed += test_function(f'IO 3.{i}', io_challenge.write_fibonacci, input, expected, type=type, _eq=(compare_file_data, get_file_data))
    print('\t-------------------------------')
    for i, (input, expected, type) in enumerate(__IO_TEST__.get(3)):
        passed += test_function(f'IO 4.{i}', io_challenge.reverse_file, input, expected, type=type, _eq=(compare_files, get_file_data))
    print('\t-------------------------------')
    for i, (input, expected, type) in enumerate(__IO_TEST__.get(4)):
        passed += test_function(f'IO 5.{i}', io_challenge.filter_errors, input, expected, type=type, _input_split=True)
    print('\t-------------------------------')
    for i, (input, expected, type) in enumerate(__IO_TEST__.get(5)):
        passed += test_function(f'IO 6.{i}', io_challenge.filter_errors_to_csv, input, expected, type=type, _input_split=True, _eq=(yaml_compare, get_file_data))
    print('\t-------------------------------')
    outcome('IO', passed, __IO_TEST__.size, force=force)

import os

def compare_files(file1, file2):
    if not os.path.exists(file1):
        return False
    with open(file1, 'r') as f1, open(file2, 'r') as f2:
        return (f1.read() == f2.read())
def compare_file_data(file, data):
    if not os.path.exists(file):
        return False
    with open(file, 'r') as f:
        return (f.read() == data)
def get_file_data(file):
    if not os.path.exists(file):
        return None
    return open(file, 'r').read()

def yaml_compare(file, data):
    if not os.path.exists(file):
        return False
    with open(file, 'r') as f:
        lines = f.read().split('\n')
    counter = 0
    dlist = data.split('\n')
    for line in lines:
        if line in ['', ' ']:
            continue
        if counter < len(dlist) and line.replace(' ', '') == dlist[counter].replace(' ', ''):
            counter += 1
        else:
            return False
    return counter == len(dlist)
